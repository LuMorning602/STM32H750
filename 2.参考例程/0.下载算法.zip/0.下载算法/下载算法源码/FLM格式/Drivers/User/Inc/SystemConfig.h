
#ifndef _BSP_H_
#define _BSP_H_


#include "stm32h7xx_hal.h"


int SystemClock_Config(void);

#endif	// _BSP_H_

