#ifndef __LCD_IMAGE_H
#define __LCD_IMAGE_H

#include <stdint.h>

// ����ͼƬ���壬�Ա������ļ�����

extern const uint8_t Image_Android_83x83[];	
extern const uint8_t Image_Cloud_83x83[];
extern const uint8_t Image_Folder_83x83[];
extern const uint8_t	Image_Message_83x83[];
extern const uint8_t	Image_Toys_83x83[];
extern const uint8_t	Image_Video_83x83[];
	
extern const uint8_t Image_FANKE_240x83[];
extern const uint8_t Image_FANKE_480x239[];

#endif  // __LCD_IMAGE_H



