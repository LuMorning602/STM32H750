#ifndef __RTC_H
#define __RTC_H 
 
 
#include "stm32h7xx_hal.h"
 
 
void MX_RTC_Init(void);	// RTC��ʼ��
 
 
#endif //__RTC_H


